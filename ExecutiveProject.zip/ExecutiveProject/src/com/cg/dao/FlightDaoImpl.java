package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.FlightInformation;
import com.cg.exception.FlightException;
import com.cg.util.DBUtil;

public class FlightDaoImpl implements FlightDao {
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    Logger empLogger=null;
   
    public FlightDaoImpl()
    {
    	
    }

	@Override
	public ArrayList<FlightInformation> getEnq(String depDate)
			throws FlightException {
		ArrayList<FlightInformation> Enquiry=new ArrayList<FlightInformation>();
        String selectQry="select flightNo,airline,depCity,arrCity,depTime from FlightInformation where depDate=?";
        try {
        	
            con=DBUtil.getCon();
            
            pst=con.prepareStatement(selectQry);
            pst.setString(1,depDate);
           
            rs=pst.executeQuery();
            
            while(rs.next())
            {
                 FlightInformation ee = new FlightInformation(rs.getInt("flightNo"),
                		rs.getString("airline"),rs.getString("depCity"),
                		rs.getString("arrCity"),rs.getString("depTime")
                	    );
                 Enquiry.add(ee);
            }
            
        } 
        catch (Exception e) {
        	
            throw new FlightException(e.getMessage());
        }
        finally
        {
            try {
            	
                rs.close();
                pst.close();
                con.close();
            } 
            catch (SQLException e) {
                throw new FlightException(e.getMessage());
            }
        }
        
        return Enquiry;
	}

	@Override
	public FlightInformation getFlight(int flightNo,String depDate) throws FlightException {
		FlightInformation EnquiryOne=new FlightInformation();
		String selectQry="select flightNo,airline,depCity,arrCity,depDate,depTime,firstSeats,availfirstSeats,bussSeat,availbussSeat from FlightInformation where flightNo=? and depDate=?";
		 try {
	        	
	            con=DBUtil.getCon();
	            
	            pst=con.prepareStatement(selectQry);
	            pst.setInt(1,flightNo);
	            pst.setString(2,depDate);
	            rs=pst.executeQuery();
	            while(rs.next())
	            {
	                        EnquiryOne = new FlightInformation(rs.getInt("flightNo"),
	                        		rs.getString("airline"),
	                		rs.getString("depCity"),rs.getString("arrCity"),
	                		rs.getString("depDate"),rs.getString("depTime"),
	                		rs.getInt("firstSeats"),rs.getInt("availfirstSeats"),
	                		rs.getInt("bussSeat"),rs.getInt("availbussSeat")
	                		
	                		);
	              
	            }
		 }
		 catch (Exception e) {
	        	
	            throw new FlightException(e.getMessage());
	        }
	        finally
	        {
	            try {
	            	
	                rs.close();
	                pst.close();
	                con.close();
	            } 
	            catch (SQLException e) {
	                throw new FlightException(e.getMessage());
	            }
	        }
	        
	        return EnquiryOne;
		}


}	



