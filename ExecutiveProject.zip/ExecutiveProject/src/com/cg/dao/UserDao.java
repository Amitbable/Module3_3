package com.cg.dao;

import com.cg.bean.User;

public interface UserDao {
	

	    public User getAuthentication(User usersBean);

	


}
