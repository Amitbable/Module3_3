package com.cg.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.FlightInformation;
import com.cg.bean.User;
import com.cg.exception.FlightException;
import com.cg.service.FLightService;
import com.cg.service.FlightServiceImpl;
import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;


public class Client {
static UserService iUserService;
static Scanner sc=new Scanner(System.in);
User usersBean=new User();
static FLightService enqSer=null;
static FlightInformation AllFlight=new FlightInformation();

static int choice= 0;
		    

	public Client() {
		        
		   }

		   
  public static void main(String[] args) {
	       
		     
	           Scanner sc=new Scanner(System.in);
		    	User usersBean=new User();
		    	enqSer = new FlightServiceImpl();
		    	int choice= 0;
		      
		       
		       
		         
		                System.out.println("Enter the username");
		                String userName = sc.next();
		                System.out.println("Enter the password");
   		                String passWord = sc.next();
		               
		                usersBean.setUserName(userName);
		                usersBean.setPassWord(passWord);
		                iUserService = new UserServiceImpl();
		                usersBean = iUserService.getAuthentication(usersBean);
		                try{
		                  if(usersBean.getRole().equalsIgnoreCase("executive")){
		                    
		                    while(true)
		    				{
		    					System.out.println("*******Flight Details*******");
		    					System.out.println("Choose an operation");
		    					System.out.println("\n1:Fetch airline Details\t"+"\n2:Fetch Flight occupancy on Id\t"+"\n0:Exit");
		    					choice=sc.nextInt();
		    					switch(choice)
		    					{
		    						case 1: fetchAll();
		    						break;
		    						case 2:getFlight();
		    						break;
		    						default:System.exit(0);
		    					
		    					}
		    				}
		                  }
		                }
		                 catch(Exception e)
		                 {
		                	e.printStackTrace();
		                 }
		    }
  public static void fetchAll()
	{
		System.out.println("Enter date on which  to be searched");
		String depDate=sc.next();
		ArrayList<FlightInformation> Enquiry=new ArrayList<FlightInformation>();
		try
		{
			Enquiry=enqSer.getEnq(depDate);
		System.out.println("flightNo \tAirline \tdeparture City\tArrival City \tdeparture Time");
		
		for(FlightInformation ee:Enquiry)
		{
			System.out.print(ee.getFlightNo());
			System.out.print("\t\t");
			System.out.print(ee.getAirline());
			System.out.print("\t\t");
			System.out.print(ee.getDepCity());
			System.out.print("\t\t");
			System.out.print(ee.getArrCity());
			System.out.print("\t\t");
			System.out.print(ee.getDepTime());
			System.out.print("\t\t");
			System.out.print("\n");
			
		}
		} catch (FlightException e) {
			System.out.println(" see error");
			e.printStackTrace();
		}
		
	}

  public static void getFlight(){
     
      System.out.println("Enter Flight Number");
      int flightNo=sc.nextInt();
      System.out.println("Enter Departure Date");
      String depDate=sc.next();
     
      FlightInformation EnquiryOne=new FlightInformation();
      try
		{
			EnquiryOne=enqSer.getFlight(flightNo,depDate);
		System.out.println("flightNo \tAirline \tdeparture City\tArrival City \tdeparture Date\tdeparture Time \tfirst class\tavail first class \tbusiness class \tavailbusiness class");
		
		System.out.print(EnquiryOne.getFlightNo());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getAirline());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getDepCity());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getArrCity());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getDepDate());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getDepTime());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getFirstSeats());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getAvailFirstSeats());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getBussSeats());
		System.out.print("\t\t");
		System.out.print(EnquiryOne.getAvailBussSeats());
		System.out.print("\t\t");
		System.out.print("\n");
		
		
			
			
		
		} catch (FlightException e) {
			System.out.println(" see error");
			e.printStackTrace();
		}
		
	} 
  }

  

