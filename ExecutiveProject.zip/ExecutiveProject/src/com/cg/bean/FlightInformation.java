package com.cg.bean;

public class FlightInformation {




	    private int flightNo;
	    private String airline;
	    private String depCity;
	    private String arrCity;
	    private String depDate;
	    private String arrDate;
	    private String depTime;
	    private String arrTime;
	    private int firstSeats;
	    private int availFirstSeats;
	    private double firstSeatFare;
	    private int bussSeats;
	    private int availBussSeats;
	    private double bussSeatsFare;

	    
		public int getFlightNo() {
			return flightNo;
		}

		public void setFlightNo(int flightNo) {
			this.flightNo = flightNo;
		}

		public String getAirline() {
			return airline;
		}

		public void setAirline(String airline) {
			this.airline = airline;
		}

		public String getDepCity() {
			return depCity;
		}

		public void setDepCity(String depCity) {
			this.depCity = depCity;
		}

		public String getArrCity() {
			return arrCity;
		}

		public void setArrCity(String arrCity) {
			this.arrCity = arrCity;
		}

		public String getDepDate() {
			return depDate;
		}

		public void setDepDate(String depDate) {
			this.depDate = depDate;
		}

		public String getArrDate() {
			return arrDate;
		}

		public void setArrDate(String arrDate) {
			this.arrDate = arrDate;
		}

		public String getDepTime() {
			return depTime;
		}

		public void setDepTime(String depTime) {
			this.depTime = depTime;
		}

		public String getArrTime() {
			return arrTime;
		}

		public void setArrTime(String arrTime) {
			this.arrTime = arrTime;
		}

		public int getFirstSeats() {
			return firstSeats;
		}

		public void setFirstSeats(int firstSeats) {
			this.firstSeats = firstSeats;
		}

		public double getFirstSeatFare() {
			return firstSeatFare;
		}

		public void setFirstSeatFare(double firstSeatFare) {
			this.firstSeatFare = firstSeatFare;
		}

		public int getBussSeats() {
			return bussSeats;
		}

		public void setBussSeats(int bussSeats) {
			this.bussSeats = bussSeats;
		}

		public double getBussSeatsFare() {
			return bussSeatsFare;
		}

		public void setBussSeatsFare(double bussSeatsFare) {
			this.bussSeatsFare = bussSeatsFare;
		}
		

		public int getAvailFirstSeats() {
			return availFirstSeats;
		}

		public void setAvailFirstSeats(int availFirstSeats) {
			this.availFirstSeats = availFirstSeats;
		}

		public int getAvailBussSeats() {
			return availBussSeats;
		}

		public void setAvailBussSeats(int availBussSeats) {
			this.availBussSeats = availBussSeats;
		}

		public FlightInformation() {
			super();
			// TODO Auto-generated constructor stub
		}

		public FlightInformation(int flightNo, String airline, String depCity,
				String arrCity,  String depTime) {
			super();
			this.flightNo = flightNo;
			this.airline = airline;
			this.depCity = depCity;
			this.arrCity = arrCity;
			this.depTime = depTime;
			
		}
		

		
		public FlightInformation(int flightNo, String airline, String depCity,
				String arrCity, String depDate, String depTime,
				int firstSeats,int availFirstSeats,int bussSeats,int availBussSeats) {
			super();
			this.flightNo = flightNo;
			this.airline = airline;
			this.depCity = depCity;
			this.arrCity = arrCity;
			this.depDate = depDate;
			
			this.depTime = depTime;
			
			this.firstSeats = firstSeats;
			this.availFirstSeats=availFirstSeats;
			this.bussSeats = bussSeats;
			this.availBussSeats=availBussSeats;
		
		}

	}


