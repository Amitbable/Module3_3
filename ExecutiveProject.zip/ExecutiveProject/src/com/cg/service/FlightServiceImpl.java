package com.cg.service;

import java.util.ArrayList;



import com.cg.bean.FlightInformation;
import com.cg.dao.FlightDao;
import com.cg.dao.FlightDaoImpl;
import com.cg.exception.FlightException;

public class FlightServiceImpl implements FLightService {
	FlightDao enqDao=new FlightDaoImpl();

	@Override
	public ArrayList<FlightInformation> getEnq(String depDate)
			throws FlightException {
	
		return enqDao.getEnq(depDate);
	}

	@Override
	public FlightInformation getFlight(int flightNo, String depDate) throws FlightException {
		// TODO Auto-generated method stub
		return enqDao.getFlight(flightNo,depDate);
	}

	

}
