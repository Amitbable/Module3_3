package com.cg.service;
import com.cg.bean.User;

public interface UserService {


	    public User getAuthentication(User usersBean);

	

	

}
