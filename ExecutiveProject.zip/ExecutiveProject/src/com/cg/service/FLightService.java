package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.FlightInformation;
import com.cg.exception.FlightException;

public interface FLightService {
	 public ArrayList<FlightInformation> getEnq(String depDate) throws FlightException;
	 public FlightInformation getFlight(int flightNo,String depDate) throws FlightException;
}
