package com.cg.admin.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.admin.dao.FlightInfoDao;
import com.cg.admin.dao.FlightInfoDaoImpl;
import com.cg.admin.dto.Airport;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.dto.Location;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.FlightException;

public class FlightInfoServiceImpl implements FlightInfoService {

	FlightInfoDao fDao=new FlightInfoDaoImpl();
	@Override
	public int insertFlightInformation(FlightInformation fi)
			throws AdminException 
	{
		
		return fDao.insertFlightInformation(fi);
	}
	@Override
	public FlightInformation getFlight(FlightInformation fi)
			throws AdminException 
	{
		
		return fDao.getFlight(fi);
	}
	@Override
	public ArrayList<FlightInformation> getFlightList(FlightInformation fi)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.getFlightList(fi);
	}
	@Override
	public int updateFlightDeptDate(LocalDate deptDate, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFlightDeptDate(deptDate, flightNo);
	}
	@Override
	public int updateFlightArrDate(LocalDate arrDate, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFlightArrDate(arrDate, flightNo);
	}
	@Override
	public int updateFirstFare(double ffare, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFirstFare(ffare, flightNo);
	}
	@Override
	public int updateBussFare(double bfare, int flightNo) throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateBussFare(bfare, flightNo);
	}
	@Override
	public int updateFlightArrTime(String atime, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFlightArrTime(atime, flightNo);
	}
	@Override
	public int updateFlightDeptTime(String dtime, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFlightDeptTime(dtime, flightNo);
	}
	@Override
	public FlightInformation getFlightData(String aCity, LocalDate aDate)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.getFlightData(aCity, aDate);
	}
	@Override
	public int updateFlightInformation(String arrCity, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateFlightInformation(arrCity, flightNo);
	}
	@Override
	public int updateDeptFlightInfo(String deptCity, int flightNo)
			throws AdminException {
		// TODO Auto-generated method stub
		return fDao.updateDeptFlightInfo(deptCity, flightNo);
	}
	@Override
	public int deleteFlightInformation(int flightNo) throws AdminException {
		// TODO Auto-generated method stub
		return fDao.deleteFlightInformation(flightNo);
	}
	@Override
	public void addAirportDetails(Airport a) throws AdminException {
		
		fDao.addAirportDetails(a);
		
	}
	@Override
	public void addLocations(Location loc) throws AdminException 
	{
		fDao.addLocations(loc);
	}
	@Override
	public ArrayList<FlightInformation> getEnq(LocalDate depDate)
			throws FlightException 
		{
		return fDao.getEnq(depDate);
	
	}
	@Override
	public FlightInformation getFlight(int flightNo, LocalDate depDate)
			throws FlightException {
		return fDao.getFlight(flightNo,depDate);
	}

	

}
