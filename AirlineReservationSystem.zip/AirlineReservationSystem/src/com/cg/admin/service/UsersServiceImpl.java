package com.cg.admin.service;

import com.cg.admin.dao.UsersDao;
import com.cg.admin.dao.UsersDaoImpl;
import com.cg.admin.dto.Users;
import com.cg.admin.exception.UserException;

public class UsersServiceImpl implements UsersService
{
  UsersDao uDao=new UsersDaoImpl();
	@Override
	public int insertUser(Users user) throws UserException 
	{
		
		return uDao.insertUser(user);
	}

	@Override
	public boolean fetchParticularUser(String username, String password)
			throws UserException 
	{
		
		return uDao.fetchParticularUser(username, password);
	}

	@Override
	public int fetchRole(String username, String password) throws UserException 
	{
		
		return uDao.fetchRole(username, password);
	}

}
