package com.cg.admin.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.admin.dto.Airport;
import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.dto.Location;
import com.cg.admin.dto.Users;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;
import com.cg.admin.exception.UserException;
import com.cg.admin.service.BookingInfoService;
import com.cg.admin.service.FlightInfoService;
import com.cg.admin.service.FlightInfoServiceImpl;
import com.cg.admin.service.IBookingInfoService;
import com.cg.admin.service.UsersService;
import com.cg.admin.service.UsersServiceImpl;
import com.cg.admin.exception.FlightException;

public class AdminClient 
{
	static Scanner sc=null;
	static FlightInfoService fSer=null;
	static FlightInformation f=new FlightInformation();
	static BookingInformation bookinfo=new BookingInformation();
	static IBookingInfoService bSer=new BookingInfoService();
	static UsersService uSer=new UsersServiceImpl();
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws NumberFormatException, IOException,AdminException, BookingException
	{
		sc=new Scanner(System.in);
		fSer=new FlightInfoServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("************WELCOME TO CAPGEMINI***********");
			System.out.println("************AIRLINE RESERVATION***********");

			System.out.println("Select an Operation");
			System.out.println("1:SIGN IN  (For Admin and Executive Only)\n"
					+ "2:SIGN UP  (For Admin and Executive Only)\n"
					+ "3:FOR BOOKING/UPDATING AIRLINE SERVICES  (For Customers Only)\n"
					+ "4:EXIT\n");
			System.out.println("********************");
			System.out.println("Please Enter a choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:Login();
			break;
			case 2:Register();
			break;
			case 3:Customer();
			break;
			case 4:
				System.out.println("THANK YOU for using CAPGEMINI'S AIRLINE RESERVATION SYSTEM");
				System.exit(0);
			default:
				System.out.println("Invalid Input");


			}
		}
	}


	public static void Customer() throws IOException, BookingException 
	{
		System.out.println("**************WELCOME CUSTOMER TO***************");
		System.out.println("************AIRLINE RESERVATION***********");
		System.out.println("Select an Operation");
		System.out.println("1.Search flights\n"
				+ "2:Book a ticket\n"
				+ "3:Delete a booked ticket\n"
				+ "4:Show booking info\n"
				+ "5:EXIT\n");
		System.out.println("********************");

		System.out.println("Please Enter a choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:searchflights();
		break;
		case 2:BookTicket();
		break;
		case 3:DeleteBookedTicket();
		break;
		case 4:ShowBookedTicket();
		break;
		case 5:Exit();
		break;

		}
	}


	private static void searchflights() throws IOException, BookingException 
	{

		System.out.println("###########    FIND YOUR FLIGHT   ##########");
		System.out.println("########### WITH OUR SEARCH WIZARD ##########");
		System.out.println("Enter Source :");
		String src =br.readLine();
		System.out.println("Enter Destination");
		String dest = br.readLine();
		ArrayList<FlightInformation> fList=bSer.searchFlightInformation(src,dest);
		fList.forEach(fl->System.out.println(fl));
	}


	private static void ShowBookedTicket() throws BookingException 
	{
		System.out.println("++++++ GRAB YOUR TICKET FOR AN AWESOME JOURNEY  ++++++");
		System.out.println("THANK YOU FOR CHOOSING US");
		System.out.println("Enter your Booking Id :");
		int vbid = sc.nextInt();
		BookingInformation b = bSer.getBookingInformation(vbid);
		System.out.println(b);

	}


	private static void DeleteBookedTicket() throws BookingException 
	{
		System.out.println("________Cancellation_______");
		System.out.println("Enter Your Booking Id :");
		int cbid = sc.nextInt();


		BookingInformation fno=bSer.getBookingInformation(cbid);
		FlightInformation updateF = new FlightInformation();
		updateF=bSer.getParticularFlight(fno.getFlightNo());
		String classType1=fno.getClassType();
		if(classType1.equalsIgnoreCase("Economy"))
		{
			if(updateF.cancelFirstSeats(fno.getNoOfPassengers()))
			{

				System.out.println("Your tickets have been cancelled with refund amount of "+(fno.getTotalFare()-500));
			}
			else
			{
				System.out.println("Sorry!!!. Cancellation failed");
			}
		}
		if(classType1.equalsIgnoreCase("Business")){
			if(updateF.cancelBussSeats(fno.getNoOfPassengers()))
			{

				System.out.println("Your tickets have been cancelled with refund amount of "+(fno.getTotalFare()-1000));
			}
			else
			{
				System.out.println("Sorry!!!. Cancellation failed");
			}
		}
		if(bSer.updateFlightSeatsCNF(updateF)){
			System.out.println("Successfully Cancelled");
		}
		else
		{
			System.out.println("Cancellation Failed...");
		}
		System.out.println(bSer.deleteBookingInformation(cbid));
	}


	private static void BookTicket() throws IOException, BookingException 
	{
		System.out.println("Enter your email");
		String email=sc.next();
		System.out.println("Enter no of Passengers");
		int noPass=sc.nextInt();
		System.out.println("Enter Class type");
		System.out.println("Business");
		System.out.println("Economy");
		String ch=sc.next();
		System.out.println("Enter credit card info");
		String creditCard=sc.next();
		System.out.println("Enter src city: ");
		String src1 =br.readLine();
		System.out.println("Enter dest city: ");
		String dest1 =br.readLine();
		ArrayList<FlightInformation> fList1=bSer.searchFlightInformation(src1,dest1);
		fList1.forEach(flight->System.out.println(flight));
		System.out.println("Specify the Flight Number :");
		int bfno = sc.nextInt();
		String s=null;
		f = bSer.getParticularFlight(bfno);

		Double totalFare=0.0;
		if(bfno ==f.getFlightNo())
		{
			System.out.println("in booking");
			if(ch.equalsIgnoreCase("Economy")){
				if(f.bookFirstSeats(noPass))
				{
					int upLim=f.getFirstSeats()-f.getAvlFirstSeats();
					int lowLim=(upLim-noPass)+1;
					int i;
					s="Your Seats are: "+lowLim;
					for(i=lowLim+1;i<=upLim;i++)
					{
						s=s+","+i;
					}
					System.out.println(s);
					totalFare = (Double) (noPass*f.getFirstSeatsFare());
					System.out.println("Total Fare for this journey is: "+totalFare);
				}
				else
				{
					System.out.println("Sorry. No Seats Available");
				}
			}
			if(ch.equalsIgnoreCase("Business")){
				if(f.bookBussSeats(noPass))
				{
					int upLim=f.getBussSeats()-f.getAvlBussSeats();
					int lowLim=(upLim-noPass)+1;
					int i;
					s="Your Seats are: "+lowLim;
					for(i=lowLim+1;i<=upLim;i++)
					{
						s=s+","+i;
					}
					System.out.println(s);
					totalFare = (Double) (noPass*f.getBussSeatsFare());
					System.out.println("Total Fare for this journey is: "+totalFare);
				}
				else
				{
					System.out.println("Sorry. No Seats Available");
				}
			}
			if(bSer.updateFlightSeatsCNF(f)){
				System.out.println("Successfully Booked");

			}
			else {
				System.out.println("Booking Failed...");

			}
		}
		else System.out.println("Invalid Value");
		BookingInformation obj=new BookingInformation(bfno,email, noPass, ch, totalFare, s, creditCard, src1, dest1);
		int bid=bSer.addNewBookingInformation(obj);
		System.out.println("Your ticket has been booked with id:"+bid);

	}


	public static void insertFlightInfo() throws NumberFormatException, IOException
	{
		try
		{
			System.out.println("************Create Flights************");
			System.out.println("Enter Flight No:");
			int fNo=Integer.parseInt(br.readLine());
			System.out.println("Enter Airways Name:");
			String airways = br.readLine();
			System.out.println("Enter City of departure: ");
			String deptCity = br.readLine();
			System.out.println("Enter Destination City: ");
			String arrCity = br.readLine();
			System.out.println("Enter Date of Departure (dd/mm/yyyy):");
			String deptDate = br.readLine();
			DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate DepartureDate = LocalDate.parse(deptDate, dtf);
			System.out.println("Enter Date of Arrival (dd/mm/yyyy):");
			String arrDate = br.readLine();
			LocalDate ArrivalDate = LocalDate.parse(arrDate, dtf);
			System.out.println("Enter depart time (in 24 hr format) eg:13:02 ");
			String deptTime = br.readLine();
			System.out.println("Enter Arrival Estimated time (in 24 hr format) eg:14:04 ");
			String arrtTime = br.readLine();
			System.out.println("Enter the number of Economy class Seats :");
			int firstSeats = Integer.parseInt(br.readLine());
			int firstSeatsAvail = firstSeats;
			System.out.println("Enter the Economy class seat fare per seat: ");
			double firstSeatsFare = Double.parseDouble(br.readLine());
			System.out.println("Enter the number of Business Class Seats :");
			int bussSeats = Integer.parseInt(br.readLine());
			int bussSeatsAvail = bussSeats;
			System.out.println("Enter the Business class seat fare per seat: ");
			double bussSeatsFare = Double.parseDouble(br.readLine());
			FlightInformation aft = new FlightInformation(fNo,airways,deptCity,arrCity,
					DepartureDate,ArrivalDate,deptTime,arrtTime,firstSeats,firstSeatsFare,bussSeats,bussSeatsFare,firstSeatsAvail,bussSeatsAvail);
			fSer.insertFlightInformation(aft);
			System.out.println("Flight inserted successfully");


		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void Login() throws IOException, NumberFormatException, AdminException
	{
		System.out.println("************Login*************");
		System.out.println("Note: This is reserved field for AIRLINE EXECUTIVE and ADMINISTRATOR only.");

		while(true)
		{
			System.out.println("Enter User Name:");
			String username = br.readLine();
			System.out.println("Enter Password:");
			String password = br.readLine();
			boolean isValid;
			try 
			{
				isValid = uSer.fetchParticularUser(username, password);
				if(isValid)
				{
					int isValidRole=uSer.fetchRole(username, password);
					switch(isValidRole)
					{
					case 1:System.out.println("::::::::WELCOME ADMINISTRATOR:::::::");
					Admin();
					break;
					case 2:System.out.println("::::::::WELCOME EXECUTIVE:::::::::");
					Executive();
					break;
					}
				}

			} 
			catch (UserException e) 
			{
				System.out.println("You are either not REGISTERED or you have entered INCORRECT"
						+ "Username/Password.\n "
						+ "Remember Username/Password are both Case Sensitive.");

			}

		}
	}
	private static void Admin() throws NumberFormatException, IOException, AdminException 
	{
		System.out.println("Select an Operation");
		System.out.println("1:Create Flight\n"
				+ "2:Delete Flight\n"
				+ "3:Update Flight\n"
				+ "4:Create Airport\n"
				+ "5:Create Location\n"
				+ "6:Special Consolidated Reports\n"
				+ "7:Sign Out\n");
		System.out.println("********************");
		System.out.println("Please Enter a choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:insertFlightInfo();
		break;
		case 2:deleteFlight();
		break;
		case 3:updateFlight();
		break;
		case 4:insertAirport();
		break;
		case 5:insertLocation();
		break;
		case 6:reports();
		break;
		case 7:signout();
		break;
		default:
			System.out.println("Invalid Input");
			System.exit(0);
		}

	}


	private static void signout() 
	{


	}


	private static void reports() throws AdminException 
	{
		System.out.println("Select an Operation");
		System.out.println("1:Generate list of flights on a particular day to a particular location \n"
				+ "2:View number of bookings for particular flight\n"
				+ "3:View passenger list for particular flight\n"
				+ "4:Back");
		System.out.println("********************");
		System.out.println("Please Enter a choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:generateList();
		break;
		case 2:viewBookings();
		break;
		case 3:viewPassengers();
		break;
		case 4:back();
		break;
		default:
			System.out.println("Invalid Input");
			System.exit(0);

		}

	}


	private static void back() {
		// TODO Auto-generated method stub

	}


	private static void viewPassengers() 
	{


		try
		{
			System.out.println("Enter Flight No:");
			int fNo=Integer.parseInt(br.readLine());
			List<BookingInformation> bList = bSer.getAllBookings(fNo);
			for(BookingInformation bi : bList)
			{
				System.out.println(bi);
			}
		}
		catch (AdminException e) 
		{
			System.out.println(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}




	private static void viewBookings() throws AdminException 
	{
		System.out.println("Please Enter Flight Number:");
		int fno=sc.nextInt();
		int count=bSer.countBookingIds(fno);
		System.out.println("Total Bookings for Flight "+fno+" is "+count);

	}


	private static void generateList() 
	{
		try 
		{
			System.out.println("Enter Destination City: ");
			String arrCity = br.readLine();

			System.out.println("Enter Date of Arrival (dd/mm/yyyy):");
			String adate = br.readLine();
			DateTimeFormatter dateFormat =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate arrd = LocalDate.parse(adate, dateFormat);

			try {
				FlightInformation  fi = fSer.getFlightData(arrCity, arrd);
				if(fi != null)
				{
					System.out.println("Flight Details: ");
					System.out.println(fi);
				}
				else
				{
					System.out.println("Sorry No Details Found ! ");
				}
			} 
			catch (AdminException e) 
			{
				System.out.println(e.getMessage());
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}	

	}


	private static void insertLocation() throws AdminException 
	{

		System.out.println("<><><><>---Locations---<><><><>");
		System.out.println("Enter city :");
		String city = sc.next();
		System.out.println("Enter State in which"+city+"is located :");
		String state = sc.next();
		System.out.println("Enter postal Zipcode:");
		String zip = sc.next();
		Location l = new Location(city,state,zip);
		fSer.addLocations(l);
		System.out.println("Location added Successfully");

	}


	private static void insertAirport() throws AdminException 
	{

		System.out.println("<><><><>---Airports---<><><><>");
		System.out.println("Enter Airport Name :");
		String name = sc.next();
		System.out.println("Enter Abbrevation Code for Airport"+name+":");
		String abb = sc.next();
		System.out.println("Enter City in which "+name+" located in:");
		String c = sc.next();
		Airport ar = new Airport(name,abb,c);
		fSer.addAirportDetails(ar);
		System.out.println("Airport created successfully");

	}


	private static void updateFlight() throws IOException 
	{
		System.out.println("Select an Operation");
		System.out.println("1:Update Flight Destination City \n"
				+ "2:Update Flight Source City\n"
				+ "3:Update Flight Departure Time\n"
				+ "4:Update Flight Arrival Time\n"
				+ "5:Update Flight Departure Date\n"
				+ "6:Update Flight Arrival Date\n"
				+ "7:Update First Class Seats Fare \n"
				+ "8:Update Business Class Seats Fare\n"
				+ "9:Back");
		System.out.println("********************");
		System.out.println("Please Enter a choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:updateFlightSourceCity();
		break;
		case 2:updateFlightDestinationCity();
		break;
		case 3:updateFlightDeptTime();
		break;
		case 4:updateFlightArrTime();
		break;
		case 5:updateDeptDate();
		break;
		case 6:updateArrDate();
		break;
		case 7:updateFirstFare();
		break;
		case 8:updateBussFare();
		break;
		case 9:Back1();
		break;
		default:
		}


	}


	private static void updateFlightDestinationCity() 
	{
		System.out.println("Enter the flight no to be updated");
		int flightNo=sc.nextInt();
		System.out.println("Enter the source city to be updated");
		String deptCity=sc.next();
		try
		{	
			int dataUpdated=fSer.updateDeptFlightInfo(deptCity, flightNo);
			if(dataUpdated==1)
			{
				System.out.println("Data Updated");
			}
			else
			{
				System.out.println("Data not updated");
			}
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}


	}


	private static void updateFlightSourceCity() 
	{
		System.out.println("Enter the flight no to be updated");
		int flightNo=sc.nextInt();
		System.out.println("Enter the destination city to be updated");
		String arrCity=sc.next();
		try
		{	
			int dataUpdated=fSer.updateFlightInformation(arrCity, flightNo);
			if(dataUpdated==1)
			{
				System.out.println("Data Updated");
			}
			else
			{
				System.out.println("Data not updated");
			}
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}

	}


	private static void updateFlightArrTime() throws IOException 
	{
		System.out.println("Enter Flight Number ");
		int fno=sc.nextInt();

		System.out.println("Enter Arrival Estimated time (in 24 hr format): ");
		String aTime = br.readLine();

		try
		{

			int dataUpdated1=fSer.updateFlightArrTime(aTime, fno);

			if((dataUpdated1==1))
			{
				System.out.println("Flight Timings Updated");
			}
			else
			{
				System.out.println("Some exception while updating");
			}
		}

		catch ( AdminException e)
		{
			System.out.println(e.getMessage());
		}	

	}


	private static void updateFlightDeptTime() throws IOException 
	{
		System.out.println("Enter Flight Number ");
		int fno=sc.nextInt();
		System.out.println("Enter departure time (in 24 hr format): ");
		String dTime = br.readLine();


		try
		{
			int dataUpdated2=fSer.updateFlightDeptTime(dTime, fno);


			if((dataUpdated2==1))
			{
				System.out.println("Flight Timings Updated");
			}
			else
			{
				System.out.println("Some exception while updating");
			}
		}

		catch ( AdminException e)
		{
			System.out.println(e.getMessage());
		}

	}


	private static void Back1() 
	{


	}


	private static void updateBussFare() 
	{
		try
		{
			System.out.println("Enter Flight No:");
			int fn = Integer.parseInt(br.readLine());
			System.out.println("Enter the Economy class seat fare per seat: ");
			double bussSeatsFare = Double.parseDouble(br.readLine());

			int fareUpdated2 = fSer.updateBussFare(bussSeatsFare, fn);
			if(fareUpdated2 == 1)
			{
				System.out.println("Flight Bussiness Fare Details Are Updated  ");
			}
			else
			{
				System.out.println("May be Some Exception while Updation");
			}
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e) 
		{

			e.printStackTrace();
		}

	}


	private static void updateFirstFare() 
	{
		try
		{
			System.out.println("Enter Flight No:");
			int fn = Integer.parseInt(br.readLine());
			System.out.println("Enter the Economy class seat fare per seat: ");
			double firstSeatsFare = Double.parseDouble(br.readLine());

			int fareUpdated1 = fSer.updateFirstFare(firstSeatsFare, fn);
			if(fareUpdated1 == 1)
			{
				System.out.println("Flight First Fare Details Are Updated  ");
			}
			else
			{
				System.out.println("May be Some Exception while Updation");
			}
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e) 
		{

			e.printStackTrace();
		}

	}


	private static void updateArrDate() 
	{
		try {
			System.out.println("Enter Flight No:");
			int fno = Integer.parseInt(br.readLine());

			DateTimeFormatter dateFormat =  DateTimeFormatter.ofPattern("dd/MM/yyyy");

			System.out.println("Enter Date of Arrival (dd/mm/yyyy):");
			String adate = br.readLine();
			LocalDate arrd = LocalDate.parse(adate, dateFormat);


			int dataUpdated1 = fSer.updateFlightArrDate(arrd, fno);


			if((dataUpdated1 == 1) )

			{

				System.out.println("Flight Arrival Date Details Are Updated  ");
			}
			else
			{
				System.out.println("May be Some Exception while Updation");
			}


		} 
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e) 
		{

			e.printStackTrace();
		}

	}


	private static void updateDeptDate() 
	{
		try {
			System.out.println("Enter Flight No:");
			int fno = Integer.parseInt(br.readLine());
			System.out.println("Enter Date of Departure (dd/mm/yyyy):");
			String ddate = br.readLine();
			DateTimeFormatter dateFormat =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate deptd = LocalDate.parse(ddate, dateFormat);





			int dataUpdated2 = fSer.updateFlightDeptDate(deptd, fno);

			if((dataUpdated2 == 1))

			{

				System.out.println("Flight Departure Date Details Are Updated  ");
			}
			else
			{
				System.out.println("May be Some Exception while Updation");
			}


		} 
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e) 
		{

			e.printStackTrace();
		}

	}


	private static void deleteFlight() 
	{
		System.out.println("Enter the flight no to be deleted");
		int flightNo=sc.nextInt();

		try
		{	
			int dataDeleted=fSer.deleteFlightInformation(flightNo);
			if(dataDeleted==1)
			{
				System.out.println("Data Deleted");
			}
			else
			{
				System.out.println("Data not Deleted");
			}
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}

	}


	private static void Executive() 
	{
		try{
			while(true)
			{
				System.out.println("*******Flight Details*******");
				System.out.println("Choose an operation");
				System.out.println("\n1:Fetch airline Details\t"+"\n2:Fetch Flight occupancy on Id\t"+"\n0:Exit");
				int choice=sc.nextInt();
				switch(choice)
				{
					case 1: fetchAll();
					break;
					case 2:getFlight();
					break;
					default:System.exit(0);
				
				}
			}
		}
		catch(Exception e)
        {
       	e.printStackTrace();
        }

	}
	  public static void fetchAll() throws IOException
		{
			System.out.println("Enter date on which  to be searched\n"
					+ "Please enter in format (dd/mm/yyyy)");
			String deptDate = br.readLine();
			DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate DepartureDate = LocalDate.parse(deptDate, dtf);
			ArrayList<FlightInformation> Enquiry=new ArrayList<FlightInformation>();
			try
			{
				Enquiry=fSer.getEnq(DepartureDate );
			System.out.println("flightNo \tAirline \tdeparture City\tArrival City \tdeparture Time");
			
			for(FlightInformation ee:Enquiry)
			{
				System.out.print(ee.getFlightNo());
				System.out.print("\t\t");
				System.out.print(ee.getAirline());
				System.out.print("\t\t");
				System.out.print(ee.getDeptCity());
				System.out.print("\t\t");
				System.out.print(ee.getArrCity());
				System.out.print("\t\t");
				System.out.print(ee.getDeptTime());
				System.out.print("\t\t");
				System.out.print("\n");
				
			}
			} catch (FlightException e) 
			{
				System.out.println(" see error");
				e.printStackTrace();
			}
			
		}

	  public static void getFlight() throws IOException{
	     
	      System.out.println("Enter Flight Number");
	      int flightNo=sc.nextInt();
	      System.out.println("Enter Departure Date in format (dd/mm/yyyy)");
	      String deptDate=br.readLine();
	      DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate DepartureDate = LocalDate.parse(deptDate, dtf);
	     
	      FlightInformation EnquiryOne=new FlightInformation();
	      try
			{
				EnquiryOne=fSer.getFlight(flightNo,DepartureDate);
			System.out.println("flightNo \tAirline \tSource \tDestination \tDeparture Date \tDeparture Time \tFirst Class Seats\tAvail First Class Seats \tBusiness Class Seats \tAvailbusiness Class Seats");
			
			System.out.print(EnquiryOne.getFlightNo());
			System.out.print("\t\t");
			System.out.print(EnquiryOne.getAirline());
			System.out.print("\t\t");
			System.out.print(EnquiryOne.getDeptCity());
			System.out.print("\t");
			System.out.print(EnquiryOne.getArrCity());
			System.out.print("\t\t");
			System.out.print(EnquiryOne.getDeptDate());
			System.out.print("\t");
			System.out.print(EnquiryOne.getDeptTime());
			System.out.print("\t\t");
			System.out.print(EnquiryOne.getFirstSeats());
			System.out.print("\t\t\t");
			System.out.print(EnquiryOne.getAvlFirstSeats());
			System.out.print("\t\t\t\t");
			System.out.print(EnquiryOne.getBussSeats());
			System.out.print("\t\t\t");
			System.out.print(EnquiryOne.getAvlBussSeats());
			System.out.print("\t\t\t");
			System.out.print("\n");
			
			
				
				
			
			} catch (FlightException e) {
				System.out.println(" see error");
				e.printStackTrace();
			}
			
		} 


	public static void Register() throws IOException
	{
		System.out.println("************REGISTER************");
		System.out.println("Note: This is reserved field for AIRLINE EXECUTIVE and ADMINISTRATOR only.");
		System.out.println("1:REGISTER AS ADMIN\n"
				+ "2:REGISTER AS AIRLINE EXECUTIVE\n"
				+ "3:EXIT\n");	
		System.out.println("********************");
		System.out.println("Please Enter a choice");
		int choice=sc.nextInt();
		while(true)
		{
			switch(choice)
			{
			case 1:RegisterAdmin();
			break;
			case 2:RegisterExecutive();
			break;
			case 3:Exit();
			break;
			default:
				System.out.println("INVALID CHOICE. Please refer Menu!!!");

			}
		}


	}


	private static void RegisterAdmin() throws IOException
	{
		System.out.println("For Security Reasons we would like to know Organization Key");
		System.out.println("HINT: "+"Organisation Name + Role."+"\n "
				+ "Please Use Camel Case.");
		String key=br.readLine();
		if(key.equals("CapgeminiAdmin"))
		{
			System.out.println("Enter Username:");
			String username=br.readLine();
			System.out.println("Enter Password");
			String password=br.readLine();
			System.out.println("Enter Mobile Number");
			String mobNo=br.readLine();
			long mobileNo=Long.parseLong(mobNo);
			Users user=new Users(username,password,"Admin",mobileNo);
			int dataAdded;
			try 
			{
				dataAdded = uSer.insertUser(user);
				if(dataAdded==1)
				{
					System.out.println("Administrator "+username+" "+"Registered Successfully.\n"
							+ "Please Remember your Username/Password for Future Reference.\n");

				}

			} 

			catch (UserException e) 
			{
				System.out.println("Something went wrong.\n"
						+ "Inconvenience while registering "+username +".");
			}

		}
		else
		{
			System.out.println("Please Enter correct Organization Key.\n");
		}

	}

	private static void RegisterExecutive() throws IOException 
	{
		System.out.println("For Security Reasons we would like to know Organization Key");
		System.out.println("HINT: Organisation Name + Role");
		String key=br.readLine();
		if(key.equals("CapgeminiExecutive"))
		{
			System.out.println("Enter Username:");
			String username=br.readLine();
			System.out.println("Enter Password");
			String password=br.readLine();
			System.out.println("Enter Mobile Number");
			String mobNo=br.readLine();
			long mobileNo=Long.parseLong(mobNo);
			Users user=new Users(username,password,"Executive",mobileNo);
			int dataAdded;
			try 
			{
				dataAdded = uSer.insertUser(user);
				if(dataAdded==1)
				{
					System.out.println("Airline Executive "+username+" "+"Registered Successfully.\n"
							+ "Please Remember your Username/Password for Future Reference.\n");

				}
			} 
			catch (UserException e) 
			{
				System.out.println("Something went wrong.Inconvenience while registering"+username +".");
			}


		}
		else
		{
			System.out.println("Please Enter correct Organization Key.\n");
		}

	}

	private static void Exit() 
	{


	}

















}
