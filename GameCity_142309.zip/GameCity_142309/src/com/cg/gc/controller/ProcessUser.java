package com.cg.gc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.gc.dto.OnlineGames;
import com.cg.gc.dto.UserBean;
import com.cg.gc.exception.UserException;
import com.cg.gc.service.UserService;
import com.cg.gc.service.UserServiceImpl;


@WebServlet(urlPatterns={"/process","/playnow"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ProcessUser() {
		super();

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = request.getServletPath(); // identifying which request is coming 
		String targetUrl = "";

		UserBean user = null;
		UserService userSer = new UserServiceImpl();


		switch(url) {

		/*
		 * Getting the input from form in gamecity.jsp
		 */
		case "/process":

			String name = request.getParameter("name");
			String address = request.getParameter("address");
			long amount = Long.valueOf( request.getParameter("amount") );
			amount -= 100;
			try {
				user = new UserBean(name, address, amount);
				long added = userSer.addUser(user);//adding user to db

				if(added == 1) {

					//creating a new session and adding UserBean
					HttpSession sess = request.getSession(true);
					sess.setAttribute("userBean", user);

					ArrayList<OnlineGames> games = userSer.showOnlineGames();//Retrieving online games from db 

					if(games != null){

						request.setAttribute("glist", games);
						targetUrl = "Play.jsp";
					}
					else {
						//showing error page if online game is not fetched
						request.setAttribute("error", "No game available as of now!");
						targetUrl = "Error.jsp";
					}
				}
				else {
					//showing error page if user is not inserted
					request.setAttribute("error", "User Info not inserted!");
					targetUrl = "Error.jsp";
				}
			} 
			catch (UserException e) {
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			break;


			/*
			 * Playing online game and updating the balance
			 */
		case "/playnow":
			HttpSession sess = request.getSession(false);
			UserBean users = (UserBean) sess.getAttribute("userBean");

			long cardBalance = users.getAmount();
			long gameAmount = Long.valueOf(request.getParameter("price"));
			
			System.out.println("balance: "+cardBalance + gameAmount);
			if(gameAmount <= cardBalance) {
				cardBalance = cardBalance - gameAmount;

				users.setAmount(cardBalance);
				sess.setAttribute("userBean", users);
				
				targetUrl = "Success.jsp";
			}
			else{
				targetUrl = "Topup.jsp";
			}

			break;

		}

		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
