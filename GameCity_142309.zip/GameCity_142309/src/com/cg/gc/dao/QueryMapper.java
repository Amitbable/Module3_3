package com.cg.gc.dao;

public interface QueryMapper {

	String INSERT_USER = "insert into users values(?,?,?,?)";
	String SELECT_SEQUENCE = "select seq_users.nextval from dual";
	String SELECT_ONLINE_GAMES = "select * from onlinegames";
}
