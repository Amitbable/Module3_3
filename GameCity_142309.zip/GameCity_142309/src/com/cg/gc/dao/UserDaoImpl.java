package com.cg.gc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.gc.dto.OnlineGames;
import com.cg.gc.dto.UserBean;
import com.cg.gc.exception.UserException;
import com.cg.gc.util.DBUtil;

public class UserDaoImpl implements UserDao {

	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public long addUser(UserBean user) throws UserException {
		
		con = DBUtil.getCon();
		long inserted = 0;
		
		try {
			pst = con.prepareStatement(QueryMapper.INSERT_USER);
			
			pst.setLong(1, generateUserId());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getAddress());
			pst.setLong(4, user.getAmount());
			
			inserted = pst.executeUpdate();
		}
		catch (SQLException e) {
			throw new UserException("Error while inserting user!");
		}
		
		return inserted;
	}

	private long generateUserId()  throws UserException {
		
		con = DBUtil.getCon();
		long id = 0;
		try {
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			
			rs.next();
			id = rs.getLong(1);
		} 
		catch (SQLException e) {
			throw new UserException("Error while inserting user!");
		}
		return id;
	}

	@Override
	public ArrayList<OnlineGames> showOnlineGames() throws UserException {
		con = DBUtil.getCon();
		ArrayList<OnlineGames> gameList = new ArrayList<OnlineGames>();
		int i=1;
		try {
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.SELECT_ONLINE_GAMES);
			
			while(rs.next()){
				OnlineGames games = new OnlineGames();
				games.setCount(i++);
				games.setName(rs.getString(1));
				games.setAmount(rs.getLong(2));
				
				gameList.add(games);
				System.out.println(games);
			}
			
		}
		catch (SQLException e) {
			throw new UserException("Error while fetching online games!");
		}
		
		return gameList;
	}

}
