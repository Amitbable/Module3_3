package com.cg.gc.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.gc.exception.UserException;


public class DBUtil {

	public static Connection getCon() throws UserException {
		
		Connection con = null;
		InitialContext context;
		
		try {
			//database configure from wildfly DSN online
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		}
		catch (Exception e) {
			throw new UserException("Unable to establish connection with data base");
		}
		
		return con;
	}
}