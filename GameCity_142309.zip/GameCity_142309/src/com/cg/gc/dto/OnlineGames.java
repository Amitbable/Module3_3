package com.cg.gc.dto;

public class OnlineGames {

	@Override
	public String toString() {
		return "OnlineGames [name=" + name + ", amount=" + amount + "]";
	}
	private String name;
	private long amount;
	private int count;
	
	public OnlineGames(String name, long amount, int count) {
		super();
		this.name = name;
		this.amount = amount;
		this.count = count;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public OnlineGames(String name, long amount) {
		super();
		this.name = name;
		this.amount = amount;
	}
	public OnlineGames() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
