package com.cg.gc.dto;

public class UserBean {

	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	private long userId;
	private String userName;
	private String address;
	private long amount;
	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", userName=" + userName
				+ ", address=" + address + ", amount=" + amount + "]";
	}
	public UserBean(long userId, String userName, String address, long amount) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.address = address;
		this.amount = amount;
	}
	
	public UserBean(String userName, String address, long amount) {
		super();
		this.userName = userName;
		this.address = address;
		this.amount = amount;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
}
