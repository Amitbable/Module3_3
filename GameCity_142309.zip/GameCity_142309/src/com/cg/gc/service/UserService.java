package com.cg.gc.service;

import java.util.ArrayList;

import com.cg.gc.dto.OnlineGames;
import com.cg.gc.dto.UserBean;
import com.cg.gc.exception.UserException;

public interface UserService {
	public long addUser(UserBean user) throws UserException;
	public ArrayList<OnlineGames> showOnlineGames() throws UserException;
}
