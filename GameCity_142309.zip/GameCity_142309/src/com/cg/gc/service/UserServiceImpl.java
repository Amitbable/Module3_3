package com.cg.gc.service;

import java.util.ArrayList;

import com.cg.gc.dao.UserDao;
import com.cg.gc.dao.UserDaoImpl;
import com.cg.gc.dto.OnlineGames;
import com.cg.gc.dto.UserBean;
import com.cg.gc.exception.UserException;

public class UserServiceImpl implements UserService {

	UserDao userDao = null;
	public UserServiceImpl() {
		userDao = new UserDaoImpl();
	}
	
	@Override
	public long addUser(UserBean user) throws UserException {
		return userDao.addUser(user);
	}

	@Override
	public ArrayList<OnlineGames> showOnlineGames() throws UserException {
		return userDao.showOnlineGames();
	}

	
	
}
