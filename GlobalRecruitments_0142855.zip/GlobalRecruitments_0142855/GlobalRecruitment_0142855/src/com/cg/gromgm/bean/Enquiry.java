package com.cg.gromgm.bean;

public class Enquiry {
	private int enqryId;
	private String firstName;
	private String lastName;
	private long  contactNumber;
	private String preferredDomain;
	private String preferredLocation;
	public int getEnqryId() {
		return enqryId;
	}
	public void setEnqryId(int enqryId) {
		this.enqryId = enqryId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPreferredDomain() {
		return preferredDomain;
	}
	public void setPreferredDomain(String preferredDomain) {
		this.preferredDomain = preferredDomain;
	}
	public String getPreferredLocation() {
		return preferredLocation;
	}
	public void setPreferredLocation(String preferredLocation) {
		this.preferredLocation = preferredLocation;
	}
	@Override
	public String toString() {
		return "Enquiry [enqryId=" + enqryId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", contactNumber=" + contactNumber
				+ ", preferredDomain=" + preferredDomain
				+ ", preferredLocation=" + preferredLocation + "]";
	}
	public Enquiry() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Enquiry(int enqryId, String firstName, String lastName,
			long contactNumber, String preferredDomain, String preferredLocation) {
		super();
		this.enqryId = enqryId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber;
		this.preferredDomain = preferredDomain;
		this.preferredLocation = preferredLocation;
	}
	
	
}
