package com.cg.gromgm.exception;

public class EnquiryException extends Exception{
	    public EnquiryException(String msg)
	    {
	        super(msg);
	    }

}


