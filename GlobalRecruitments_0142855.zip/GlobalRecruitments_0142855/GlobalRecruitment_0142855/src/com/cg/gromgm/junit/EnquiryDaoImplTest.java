package com.cg.gromgm.junit;
import junit.framework.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.dao.EnquiryDao;
import com.cg.gromgm.dao.EnquiryDaoImpl;
import com.cg.gromgm.exception.EnquiryException;

public class EnquiryDaoImplTest {
	    static int enqryid;
		static EnquiryDao enqDao=null;
		static Enquiry ee=null;
		@BeforeClass
		public static void beforeClass() throws EnquiryException
		{
			enqDao=new EnquiryDaoImpl();
			ee=new Enquiry(enqDao.generateEnquiryId(),"Amit","Bable",8600436178L,"Java","Pune");
		}
		@Test
		public void testAddEmp1() throws EnquiryException
		{
			Assert.assertEquals(1, enqDao.addEnq(ee));
			
		}
		@Test(expected =Exception.class)
		public void testAddEmp2() throws EnquiryException
		{
			Assert.assertEquals(1, enqDao.addEnq(ee));
			
		}
		@Test
		public void testAddEmp3() throws EnquiryException
		{
			Assert.assertNotNull(enqDao.getEnq(enqryid));
			
		}
}


