package com.cg.gromgm.service;
import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.dao.EnquiryDao;
import com.cg.gromgm.dao.EnquiryDaoImpl;
import com.cg.gromgm.exception.EnquiryException;

public class EnquiryServiceImpl implements EnquiryService{
	

		EnquiryDao enqDao=null;
		public EnquiryServiceImpl()
		{
			enqDao=new EnquiryDaoImpl();
		}
		public int addEnq(Enquiry enq) throws 
		EnquiryException {
			return enqDao.addEnq(enq);

		}

		@Override
		public ArrayList<Enquiry> getEnq(int enqryId) 
				throws EnquiryException {

			return enqDao.getEnq(enqryId);
		}

		@Override
		public int generateEnquiryId() throws
		EnquiryException {
			return enqDao.generateEnquiryId();
		}

		@Override
		public boolean validateDigit(long contactNumber) throws 
		EnquiryException {

			String numPattern="[7-9][0-9]{9}";
			if(Pattern.matches(numPattern,new Long(contactNumber).toString()))
			{
				return true;
			}
			else
			{
				throw new EnquiryException
				("contact number should be 10 digit valid mobile number");
			}
		}

		@Override
		public boolean validateName(String firstName) throws 
		EnquiryException {
			String namePattern="[A-Z][a-z]+";
			if(Pattern.matches(namePattern,firstName))
			{           
				return true;
			}
			else
			{
				throw new EnquiryException
				("Name should start with capital letter and cannot be empty");
			}
		}
		@Override
		public boolean validatePreferredDomain(String preferredDomain) throws 
		EnquiryException {
			String namePattern="[A-Za-z]+";
			if(Pattern.matches(namePattern,preferredDomain))
			{           
				return true;
			}
			else
			{
				throw new EnquiryException
				("preferred Domain cannot be empty");
			}
		}
		@Override
		public boolean validatePreferredLocation(String preferredLocation) throws 
		EnquiryException {
			String namePattern="[A-Za-z]+";
			if(Pattern.matches(namePattern,preferredLocation))
			{           
				return true;
			}
			else
			{
				throw new EnquiryException
				("preferred location cannot be empty");
			}
		}		

}



