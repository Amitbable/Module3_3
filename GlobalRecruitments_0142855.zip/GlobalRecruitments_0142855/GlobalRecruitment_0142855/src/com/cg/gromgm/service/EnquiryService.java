package com.cg.gromgm.service;
import java.util.ArrayList;

import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.exception.EnquiryException;

public interface EnquiryService {
	
	    
	    public int addEnq(Enquiry enq)
	            throws EnquiryException;
	            
	           
	            public int generateEnquiryId() throws EnquiryException;
	            public ArrayList<Enquiry> getEnq(int enqryId) throws EnquiryException;
	            public boolean validateDigit(long contactNumber) throws EnquiryException;
	            public boolean validateName(String firstName) throws EnquiryException;
	            public boolean validatePreferredLocation(String preferredLocation) throws EnquiryException;
	            public boolean validatePreferredDomain(String preferredDomain) throws EnquiryException;

			

}



