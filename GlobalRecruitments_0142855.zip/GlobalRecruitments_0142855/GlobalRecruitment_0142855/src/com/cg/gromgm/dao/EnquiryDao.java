package com.cg.gromgm.dao;
import java.util.ArrayList;
import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.exception.EnquiryException;
public interface EnquiryDao {

	    public int addEnq(Enquiry enp)
	    throws EnquiryException;
	    
	  
	    public int generateEnquiryId() throws EnquiryException;	    
	    public ArrayList<Enquiry> getEnq(int enqryid) throws EnquiryException;
}


