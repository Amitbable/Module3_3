package com.cg.gromgm.dao;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.exception.EnquiryException;
import com.cg.gromgm.util.DBUtil;

public class EnquiryDaoImpl implements EnquiryDao{

	    Connection con=null;
	    Statement st=null;
	    PreparedStatement pst=null;
	    ResultSet rs=null;
	    Logger empLogger=null;
	    {
	    	PropertyConfigurator.configure("resources/log4j.properties");
	    	empLogger=Logger.getLogger("EnquiryDaoImpl.class");
	    }
	    public EnquiryDaoImpl()
	    {
	    	
	    }
	    @Override
	    public int addEnq(Enquiry enq) throws EnquiryException{
	        String insertQry="INSERT INTO Enquiry(enqryid,firstName,lastName,contactNumber,preferredDomain,preferredLocation) values (?,?,?,?,?,?) ";
	        int dataAdded;
	        try
	        {
	            
	            con=DBUtil.getCon();
	            pst=con.prepareStatement(insertQry);
	            pst.setInt(1,generateEnquiryId());
	            pst.setString(2,enq.getFirstName());
	            pst.setString(3,enq.getLastName());
	            pst.setLong(4,enq.getContactNumber());
	            pst.setString(5,enq.getPreferredDomain());
	            pst.setString(6,enq.getPreferredLocation());
	            dataAdded=pst.executeUpdate();
	            empLogger.log(Level.INFO,"Enq Inserted: "+enq);
	        }
	        catch(Exception e)
	        {
	            throw new EnquiryException(e.getMessage());
	        }
	        finally
	        {
	            try {
	                pst.close();
	                con.close();
	                
	            } 
	            catch (SQLException e) {
	                empLogger.error("This is xception:"+e.getMessage());
	                throw new EnquiryException(e.getMessage());
	            }
	            
	        }
	        return dataAdded;
	        
	    }

	   
	    @Override
	    public int generateEnquiryId() throws EnquiryException {
	        String qry="SELECT enquiries.NEXTVAL FROM DUAL";
	        int generatedVal;
	        try
	        {
	            con=DBUtil.getCon();
	            st=con.createStatement();
	            rs=st.executeQuery(qry);
	            rs.next();
	             generatedVal=rs.getInt(1);
	        } 
	        catch (Exception e) {
	            
	            throw new EnquiryException(e.getMessage());
	        }
	        finally
	        {
	            try {
	                rs.close();
	                st.close();
	                con.close();
	            } 
	            catch (SQLException e) {
	                throw new EnquiryException(e.getMessage());
	            }
	        }
	        return generatedVal;
	    }
	   
	    @Override
	    public ArrayList<Enquiry> getEnq(int enqryId) throws EnquiryException {
	        ArrayList<Enquiry> EnquiryOne=new ArrayList<Enquiry>();
	        String selectQry="select * from enquiry where enqryid=?";
	        try {
	            
	            con=DBUtil.getCon();
	            
	            pst=con.prepareStatement(selectQry);
	            pst.setInt(1,enqryId);
	           
	            rs=pst.executeQuery();
	            
	            while(rs.next())
	            {
	                 Enquiry ee = new Enquiry(rs.getInt("enqryId"),rs.getString("firstName"),
	                		rs.getString("lastName"),rs.getLong("ContactNumber"),
	                		rs.getString("preferredDomain"),rs.getString("preferredLocation"));
	                 EnquiryOne.add(ee);
	            }
	            
	        } 
	        catch (Exception e) {
	            throw new EnquiryException(e.getMessage());
	        }
	        finally
	        {
	            try {
	            	pst.close();
	                rs.close();
	                
	                con.close();
	            } 
	            catch (SQLException e) {
	                throw new EnquiryException(e.getMessage());
	            }
	        }
	        
	        return EnquiryOne;
	    }
	   


	}


