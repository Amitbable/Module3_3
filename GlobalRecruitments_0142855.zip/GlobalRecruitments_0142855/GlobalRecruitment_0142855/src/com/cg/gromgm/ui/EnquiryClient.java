package com.cg.gromgm.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.gromgm.service.EnquiryService;
import com.cg.gromgm.service.EnquiryServiceImpl;
import com.cg.gromgm.bean.Enquiry;
import com.cg.gromgm.exception.EnquiryException;

public class EnquiryClient {
			
			static Scanner sc=null;
			static int choice=0;
			static EnquiryService empSer=null;
			public static void main(String [] args)
			{
				sc=new Scanner(System.in);
				empSer=new EnquiryServiceImpl();
				while(true)
				{
					System.out.println("*******Global Recruitmnts*******");
					System.out.println("Choose an operation");
					System.out.println("\n1:Enter Enquiry Details\t"+"\n2:View Enquiry Details on Id\t"+"\n0:Exit");
					choice=sc.nextInt();
					switch(choice)
					{
						case 1: insertEnq();
						break;
						case 2:searchEnq();
						break;
						default:System.exit(0);
					
					}
				}
			
			}	
			
			public static void insertEnq() 
			{
				System.out.println("Enter First Name");
				String firstName=sc.next();
				try 
				{
					if(empSer.validateName(firstName))
					{
						System.out.println("Enter Last Name");
						String lastName=sc.next();
						System.out.println("Enter Mobile no");
						long contactNumber=sc.nextLong();
						
						if(empSer.validateDigit(contactNumber))
						{
							System.out.println("Enter preferred domain");
							String preferredDomain=sc.next();
							
							if(empSer.validatePreferredDomain(preferredDomain))
							{
								System.out.println("Enter preferred location");
								String preferredLocation=sc.next();
								
								if(empSer.validatePreferredLocation(preferredLocation))
								{
									Enquiry ee=new Enquiry();
									ee.setFirstName(firstName);
									ee.setLastName(lastName);
									ee.setContactNumber(contactNumber);
									ee.setPreferredDomain(preferredDomain);
									ee.setPreferredLocation(preferredLocation);
								
									int dataAdded=empSer.addEnq(ee);
									if(dataAdded==1)
									{
										System.out.println("data added");
									}
									else
									{
										System.out.println("May Some Exception"+"while addition");
									}
								}
							}
						}
					}
				}
							catch (EnquiryException e)
							{
								System.out.println(e.getMessage());
							}
						
			}	
			/***************************************************/
				public static void searchEnq() 
				{
					System.out.println("Enter enquiry id to be searched");
					int enqryId=sc.nextInt();
					
					try
					{
						ArrayList<Enquiry>EnquiryOne=empSer.getEnq(enqryId);
					
					
					for(Enquiry ee:EnquiryOne)
					{
					//	System.out.println("Id \t First Name\t Last Name\t Contact Number\t Preferred Domain\t preferred Location");
						System.out.println(ee);
					}
					} catch (EnquiryException e) {
						System.out.println(" see error");
						e.printStackTrace();
					}
					
					
				}
				
			/***************************************************/
			
	}


