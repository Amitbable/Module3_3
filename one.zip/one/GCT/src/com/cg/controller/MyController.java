package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.ShowException;
import com.cg.service.GameService;
import com.cg.service.GameServiceImpl;

@WebServlet({"/purchase","/home","/buy"})
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public MyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getServletPath();
		String targetUrl="";
		GameService mser= new GameServiceImpl();
		switch(url){
		    case "/purchase":
                Users gDetails=new Users();
				
				gDetails.setUserName(request.getParameter("cname"));
				gDetails.setUserAddress(request.getParameter("address"));
				Double userAmt=(Double.parseDouble(request.getParameter("amount"))-100);
				gDetails.setCardAmt(userAmt);
				
				
			try {
				mser.insertUserDetails(gDetails);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("gDetails", gDetails);
				List<Games> gList = mser.getAllGames();
				sess.setAttribute("gList", gList);
				System.out.println("Home");
				targetUrl = "Home.jsp";
				
				
			} catch (ShowException e) {
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		    
		    break;
		
			case"/buy":
				Double price=Double.parseDouble(request.getParameter("mid"));
				
				HttpSession sess=request.getSession();
				Users gtails=(Users) sess.getAttribute("gDetails");
				Double costTwo =gtails.getCardAmt(); 
				Double priceOne=costTwo-price;
				
				request.setAttribute("cost",priceOne);
				targetUrl = "Success.jsp";
				break;
	}
		RequestDispatcher disp=
				request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);

	}
}
