package com.cg.service;

import java.util.List;




import com.cg.dao.GameDao;
import com.cg.dao.GameDaoImpl;
import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.ShowException;

public class GameServiceImpl implements GameService {
	
	GameDao gdo =new GameDaoImpl();
	public GameServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Games> getAllGames() throws ShowException {
		return gdo.getAllGames();
	}

	@Override
	public long insertUserDetails(Users gDetails) throws ShowException {
		return gdo.insertUserDetails(gDetails);
	}

}
