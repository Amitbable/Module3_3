package com.cg.service;

import java.util.List;

import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.ShowException;

public interface GameService {
List<Games> getAllGames() throws ShowException;
	
	long insertUserDetails(Users gDetails) throws  ShowException;


}
