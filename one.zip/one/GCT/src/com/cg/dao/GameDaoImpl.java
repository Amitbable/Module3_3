package com.cg.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Games;
import com.cg.dto.Users;
import com.cg.exception.ShowException;





public class GameDaoImpl implements GameDao {

	public GameDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	Connection conn;
	@Override
	public List<Games> getAllGames() throws ShowException {
		List<Games> mlist=new ArrayList<>();
		conn=DBUtil.getCon();
		
		ResultSet rst;
		try {
			Statement st=conn.createStatement();
			rst = st.executeQuery(QueryMapper.SELECT_ALL);
			while(rst.next()){
				Games m=new Games();
				m.setGameName(rst.getString("name"));
				m.setGameAmt(rst.getDouble("amount"));
				
				mlist.add(m);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mlist;	
	}
	private long generateUserId()
			throws ShowException {
		long pid=0;
		conn=DBUtil.getCon();
		try{
			Statement st= conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid=rst.getLong(1);
		}catch(SQLException e){
			throw new ShowException("Problem in generating purchase id:"+e.getMessage());
		}
		return pid;
	}
	@Override
	public long insertUserDetails(Users gDetails) throws ShowException {
		conn=DBUtil.getCon();
		gDetails.setUserId(generateUserId());
		try{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_USER_INFO);
			
			pst.setLong(1,gDetails.getUserId());
            pst.setString(2,gDetails.getUserName());
            pst.setString(3,gDetails.getUserAddress());
            pst.setDouble(4,gDetails.getCardAmt());
           
			pst.executeUpdate();
		}catch(SQLException e){
			
		}
		return gDetails.getUserId();
	}

}
