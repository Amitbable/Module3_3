package com.cg.dao;

public interface QueryMapper {
	String SELECT_ALL="select * from onlinegames";
	String SELECT_SEQUENCE = "Select seq_users.NEXTVAL FROM DUAL";
	String INSERT_USER_INFO = "INSERT INTO users(user_id,user_name,address,card_amt) VALUES(?, ?, ?, ?)";

}
