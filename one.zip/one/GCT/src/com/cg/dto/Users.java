package com.cg.dto;

public class Users {

	//Instance variable declaration
	private long userId;
	private String userName;
	private String userAddress;
	private double cardAmt;
	
	//constructors declaration
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(long userId, String userName, String userAddress,
			double cardAmt) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userAddress = userAddress;
		this.cardAmt = cardAmt;
	}
	//Getters and Setters methods for outside class parameter access
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public double getCardAmt() {
		return cardAmt;
	}
	public void setCardAmt(double cardAmt) {
		this.cardAmt = cardAmt;
	}
	
	
}
