package com.cg.dto;

public class Games {
 
	//Instance variable declaration
	private String gameName;
	private double gameAmt;
	
	//constructors declaration
	public Games() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Games(String gameName, double gameAmt) {
		super();
		this.gameName = gameName;
		this.gameAmt = gameAmt;
	}
	
	//Getters and Setters methods for outside class parameter access
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public double getGameAmt() {
		return gameAmt;
	}
	public void setGameAmt(double gameAmt) {
		this.gameAmt = gameAmt;
	}
	
}
