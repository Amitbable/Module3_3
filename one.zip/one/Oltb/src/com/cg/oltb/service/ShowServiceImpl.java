package com.cg.oltb.service;

import java.util.List;

import com.cg.oltb.dao.ShowDao;
import com.cg.oltb.dao.ShowDaoImpl;
import com.cg.oltb.dto.Show;
import com.cg.oltb.exception.ShowException;

public class ShowServiceImpl implements ShowService {
	ShowDao show= new ShowDaoImpl();
	@Override
	public List<Show> getAllShows() throws ShowException {
		// TODO Auto-generated method stub
		 return show.getAllShows();
	}
	@Override
	public Show getShowDetail(String showid) throws ShowException {
		// TODO Auto-generated method stub
		return show.getShowDetail(showid);
	}
	@Override
	public int updateShowDetails(int seats, String showname)
			throws ShowException {
		
		return show.updateShowDetails(seats,showname);
	}

}
