package com.cg.oltb.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.oltb.dto.Show;
import com.cg.oltb.exception.ShowException;
import com.cg.oltb.service.ShowService;
import com.cg.oltb.service.ShowServiceImpl;


/**
 * Servlet implementation class MyController
 */
@WebServlet({"/home","/BookNow","/BookTicket"})
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getServletPath();
		String targetUrl="";
		ShowService mser= new ShowServiceImpl();
		switch(url){
		
			case"/home":
		try{
				List<Show> mlist= mser.getAllShows();
				request.setAttribute("mlist",mlist);
				targetUrl="home.jsp";
		}catch(ShowException e){
			request.setAttribute("Error",e.getMessage());
			targetUrl="error.jsp";
		}break;
			
			case"/BookNow":
				String mid=request.getParameter("showid");
				try{
					Show s= mser.getShowDetail(mid);
					HttpSession sess=request.getSession(true);
					sess.setAttribute("s", s);
					targetUrl="Insert.jsp";
				}catch(ShowException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="Error.jsp";
				}
				break;
			case "/BookTicket":
				String showName = request.getParameter("ShowName");
				double price = Double.parseDouble(request.getParameter("Price")) ;
				String customerName = request.getParameter("CustName");
				long mob =Long.parseLong(request.getParameter("MobNo"));
				int availSeats = Integer.parseInt(request.getParameter("SeatsAvail"));
				int noOfSeats = Integer.parseInt(request.getParameter("SeatsBook"));
		        
				int updatedSeats = availSeats-noOfSeats ;
				request.setAttribute("showname", showName);
				request.setAttribute("cname", customerName);
				request.setAttribute("mobileNo", mob);
				request.setAttribute("noOfSeats", noOfSeats);
				double totalPrice = price * noOfSeats ;
				request.setAttribute("totalPrice", totalPrice);
				
			
			
			try {
				
				
				mser.updateShowDetails(updatedSeats, showName);
			} catch (ShowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				targetUrl="success.jsp";
			
			
				
			
				
				
			
			break ;
		
	}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request,response);
	}
}

