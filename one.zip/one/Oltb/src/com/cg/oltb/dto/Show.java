package com.cg.oltb.dto;

import java.sql.Date;



public class Show {
	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int avSeats;
	private double priceTicket;
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public double getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}
	public Show(String showId, String showName, String location, Date showDate,
			int avSeats, double priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avSeats = avSeats;
		this.priceTicket = priceTicket;
	}
	public Show() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
