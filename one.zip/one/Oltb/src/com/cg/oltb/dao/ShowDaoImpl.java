package com.cg.oltb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



import com.cg.oltb.dao.DBUtil;
import com.cg.oltb.dao.QueryMapper;
import com.cg.oltb.dto.Show;
import com.cg.oltb.exception.ShowException;
import com.cg.oltb.dto.Show;


public class ShowDaoImpl implements ShowDao {
	Connection conn;
	@Override
	public List<Show> getAllShows() throws ShowException {
			List<Show> mlist=new ArrayList<>();
			conn=DBUtil.getCon();
			
			ResultSet rst;
			try {
				Statement st=conn.createStatement();
				rst = st.executeQuery(QueryMapper.SELECT_ALL_SHOWS);
				while(rst.next()){
					Show m=new Show();
					m.setShowId(rst.getString("showid"));
					m.setShowName(rst.getString("showname"));
					m.setLocation(rst.getString("location"));
					m.setShowDate(rst.getDate("showdate"));
					m.setAvSeats(rst.getInt("avseats"));
					m.setPriceTicket(rst.getDouble("priceticket"));
					mlist.add(m);
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return mlist;	
		}
	@Override
	public Show getShowDetail(String showid) throws ShowException {
		conn=DBUtil.getCon();
		Show m= new Show();
		try {
		
		PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_DETAILS);
		pst.setString(1,showid);
		ResultSet rst=pst.executeQuery();
			if(rst.next()){
			
				m.setShowId(rst.getString("showid"));
				m.setShowName(rst.getString("showname"));
				m.setLocation(rst.getString("location"));
				m.setShowDate(rst.getDate("showdate"));
				m.setAvSeats(rst.getInt("avseats"));
				m.setPriceTicket(rst.getDouble("priceticket"));
			System.out.println(m);
			}
			else{
				throw new ShowException("Mobile not found");
			}
		}
			catch(SQLException e){
				
				throw new ShowException("Problem in fetching mobile");
			}
			return m;
	
	}
	@Override
	public int updateShowDetails(int seats, String showname)
			throws ShowException {
		int updateData=0;
		conn=DBUtil.getCon();
		Show m= new Show();
		try {
		
		PreparedStatement pst=conn.prepareStatement(QueryMapper.UPDATE_QUERY);
		pst.setInt(1,seats);
		pst.setString(2,showname);
		updateData=pst.executeUpdate();
		System.out.println(updateData);
		
			
		}
			catch(SQLException e){
				
				throw new ShowException("Problem in updating");
			}
		return updateData;
	
		
	}

}


