package com.cg.oltb.dao;

import java.util.List;
import com.cg.oltb.dto.Show;
import com.cg.oltb.exception.ShowException;

public interface ShowDao {
	List<Show> getAllShows() throws ShowException;
	public Show getShowDetail(String showid) throws ShowException ;
	public int updateShowDetails(int seats , String showname) throws ShowException ;
}
