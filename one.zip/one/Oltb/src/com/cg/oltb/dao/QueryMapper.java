package com.cg.oltb.dao;

public interface QueryMapper {

	String SELECT_ALL_SHOWS="SELECT ShowID, Showname, location, showdate,avseats,priceticket FROM showdetails";
	String SELECT_DETAILS="select ShowId,ShowName,Location,ShowDate,"
			+ "AvSeats,PriceTicket from showdetails where showid=?";
	String UPDATE_QUERY="update showdetails set AvSeats = ? where ShowName = ?";
}
