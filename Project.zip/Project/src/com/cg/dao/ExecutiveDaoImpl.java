package com.cg.dao;

import com.cg.bean.Airport;
import com.cg.bean.FlightInformation;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.util.DBUtil;



public class ExecutiveDaoImpl implements ExecutiveDao {

 Logger logger = Logger.getRootLogger();

    Connection connection;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    public  ExecutiveDaoImpl(){

        PropertyConfigurator.configure("resources//log4j.properties");
    }
    //------------------------ 1.Airline Book --------------------------
            /*******************************************************************************************************
                         - Function Name    :   fetchDetails()
                         - Input Parameters :   airportBean,flightInformation
                         - Return Type      :   AirportBean
                         - Throws           :   AirlineException
                         - Author           :   Team 5
                         - Creation Date    :   16/10/2017
                         - Description      :   Fetching details of flightInformation table and show occupancy details
             ********************************************************************************************************/
    @Override
    public FlightInformation fetchDetails(Airport airportBean, FlightInformation flightInformation) {
        // TODO Auto-generated method stub
        try {

            String name = flightInformation.getAirline();

            System.out
                    .println("flightinfo as follows:\n -----------------------");
            System.out.println("Airline\tFirstSeats\tBussSeats");
            String query = "select airline, sum(firstseats),sum (BussSeats)from FLIGHTINFORMATION where flightNo=? group by airline";
            connection = DBUtil.getConnection();

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, flightInformation.getFlightNo());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                // Data to diaplay

                System.out.println(resultSet.getString(1) + "\t\t"
                        + resultSet.getInt(2) + "\t" + resultSet.getInt(3));

            }
        } catch (Exception e) {
            logger.error("Flight Occupancy Details is not retreived.");
        }
        logger.info("Flight Occupancy Details retreived.");
        return flightInformation;
    }
    //------------------------ 1.Airline Book --------------------------
    /*******************************************************************************************************
                 - Function Name    :    occupancyDetails()
                 - Input Parameters :   airportBean,flightInformation
                 - Return Type      :   AirportBean
                 - Throws           :   AirlineException
                 - Author           :   Team 5
                 - Creation Date    :   16/10/2017
                 - Description      :   Fetching details of flightInformation table and show occupancy details
     ********************************************************************************************************/
    @Override
    public FlightInformation occupancyDetails(Airport airportBean,FlightInformation flightInformation) {
        try {

            String query = "select airline,sum(bussSeats),sum(firstseats) from flightinformation where dep_city=? and dep_date=? group by airline";
            connection = DBUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, flightInformation.getDepCity());
            preparedStatement.setString(2, flightInformation.getDepDate());

            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Flight Information is as follows:");
                System.out.println("********************************");
                System.out.println("Airline FirstSeats BussSeats");
                while (resultSet.next()) {

                    System.out.println(resultSet.getString(1) + "\t"
                            + resultSet.getInt(2) + "\t"
                            + resultSet.getInt(3));
                }
            } else {
                logger.error("Wrong data entered by executive.");
                System.out.println("You have entered wrong data..");
            }
        } catch (Exception e) {
            logger.error("Flight Occupancy Details is not retreived.");
        }
        logger.info("Flight Occupancy Details retreived.");
        return flightInformation;
    }

}