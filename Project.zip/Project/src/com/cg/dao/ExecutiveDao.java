package com.cg.dao;

import com.cg.bean.Airport;
import com.cg.bean.FlightInformation;


public interface ExecutiveDao {
	

	    FlightInformation fetchDetails(Airport airportBean,FlightInformation flightInformation);

	    FlightInformation occupancyDetails(Airport  airportBean,FlightInformation flightInformation);

	
}
