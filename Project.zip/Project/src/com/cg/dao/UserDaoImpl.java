package com.cg.dao;

import com.cg.bean.User;
import java.sql.Connection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.naming.NamingException;

import com.cg.bean.User;
import com.cg.exception.AirlineException;
import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao {

   Logger logger = Logger.getRootLogger();
   Connection con;

   /**
    * @throws AirlineException
    * @throws SQLException
    * @throws NamingException
    * 
    */
   public UserDaoImpl() throws NamingException, SQLException, AirlineException {
       // TODO Auto-generated constructor stub
       PropertyConfigurator.configure("resources//log4j.properties");

   }

   @Override
   public User getAuthentication(User usersBean) {
       // TODO Auto-generated method stub
       PreparedStatement preparedStatement = null;
       ResultSet resultSet = null;

       try {
           Connection connection = DBUtil.getConnection();

           String query = "select role,mobile_no from users where  USERNAME='" + usersBean.getUserName()
                   + "' and PASSWORD='" + usersBean.getPassWord() + "'";

           preparedStatement = connection.prepareStatement(query);
           resultSet = preparedStatement.executeQuery();
           // System.out.println(resultSet.getFetchSize());
           resultSet.next();
           // System.out.println(resultSet.getString(3));
           usersBean.setRole(resultSet.getString(1));
           usersBean.setMobileNo(resultSet.getLong(2));
           logger.info("Admin is authenticated.");

       } catch (NamingException e) {
           // TODO Auto-generated catch block

       } catch (SQLException e) {
           // TODO Auto-generated catch block

       } catch (Exception e) {

       }
       return usersBean;
   }

  

}