package com.cg.service;

import com.cg.bean.Airport;
import com.cg.bean.FlightInformation;
import com.cg.dao.ExecutiveDaoImpl;
import com.cg.dao.ExecutiveDao;




public class ExecutiveServiceImpl implements ExecutiveService {
	ExecutiveDao iAirportDao;
	
	public ExecutiveServiceImpl() {
        // TODO Auto-generated constructor stub
        iAirportDao=new ExecutiveDaoImpl();
    }
	
	@Override
	public FlightInformation fetchDetails(Airport airportBean,
			FlightInformation flightInformation) {
		
		 return iAirportDao.fetchDetails(airportBean,flightInformation);
	}

	@Override
	public FlightInformation occupancyDetails(Airport airportBean,
			FlightInformation flightInformation) {
		
		 return iAirportDao.occupancyDetails(airportBean,flightInformation);
	}

}


