package com.cg.service;

import com.cg.bean.User;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.bean.User;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.exception.AirlineException;

public class UserServiceImpl implements UserService {
	
	UserDao iUserDao;
	 public UserServiceImpl() {
		 
	        // TODO Auto-generated constructor stub
	    }

	@Override
	public User getAuthentication(User usersBean) {
		  try {
	            iUserDao = new UserDaoImpl();
	        } catch (NamingException e) {
	           
	            
	        } catch (SQLException e) {
	           
	            
	        } catch (AirlineException e) {
	          
	            
	        }
	        return iUserDao.getAuthentication(usersBean);
	}

	

}




   

