package com.cg.service;

import com.cg.bean.Airport;
import com.cg.bean.FlightInformation;

public interface ExecutiveService {


	

	    FlightInformation fetchDetails(Airport airportBean,FlightInformation flightInformation);

	    FlightInformation occupancyDetails(Airport airportBean, FlightInformation flightInformation);


}
