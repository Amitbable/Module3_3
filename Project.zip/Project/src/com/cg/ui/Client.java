package com.cg.ui;

import java.util.Scanner;


import com.cg.bean.Airport;

import com.cg.bean.FlightInformation;
import com.cg.bean.User;

import com.cg.service.ExecutiveServiceImpl;


import com.cg.service.ExecutiveService;


import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;




	


	public class Client {
	   
		static ExecutiveService iAirportService;
		static UserService iUserService;
	    

	    public Client() {
	        
	    }

	   
	    public static void main(String[] args) {
	     
	    	User usersBean=new User();
	        Airport airportBean=new Airport();
	        FlightInformation flightInformation= null;
	        int choice = 0;
	       
	         
	                System.out.println("Enter the username");
	                String userName = new Scanner(System.in).nextLine();
	                System.out.println("Enter the password");

	                String passWord = new Scanner(System.in).nextLine();
	               
	                usersBean.setUserName(userName);
	                usersBean.setPassWord(passWord);
	                iUserService = new UserServiceImpl();
	                usersBean = iUserService.getAuthentication(usersBean);

	                 if (usersBean.getRole().equalsIgnoreCase("executive")) {
	                    System.out.println("Enter the Airport Location");
	                    String location = new Scanner(System.in).nextLine();
	               
	                  
	                    while (choice < 3) {
	                        System.out.println("Welcome! which information you want? \n1.Available Flights on Date\n2Flight Occupancy\n3Exit");
	                        
	                        flightInformation = new FlightInformation();
	                        choice=new Scanner(System.in).nextInt();
	                     
	                        iAirportService=new ExecutiveServiceImpl();
	                        if (choice == 1) {
	                            
	                            System.out.println("Enter the Airport Name"); 
	                            flightInformation.setDepCity(new Scanner(System.in).nextLine());
	                            System.out.println("Date in DD-MM-YYYY format");
	                            flightInformation.setDepDate(new Scanner(System.in).nextLine());
	                            flightInformation=iAirportService.occupancyDetails(airportBean,flightInformation);
	                          

	                        } else if (choice == 2) {
	                            // Occupancy Details
	                            System.out.println("Enter Flight Number");
	                            flightInformation.setFlightNo(new Scanner(System.in).nextLine());
	                            flightInformation=iAirportService.fetchDetails(airportBean,flightInformation);
	                        } else {
	                            System.exit(0);
	                        }
	                    }

	                }
	            } 
	        
	    }
	


