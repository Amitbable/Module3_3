package com.cg.springdemothree.dao;

public interface EmployeeDao {
	public void getData();
}
