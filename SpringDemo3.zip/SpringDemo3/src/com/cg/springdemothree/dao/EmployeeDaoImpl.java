package com.cg.springdemothree.dao;

import org.springframework.stereotype.Component;

@Component("Employeedao")
public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public void getData() {
		System.out.println("In the Dao");

	}

}
