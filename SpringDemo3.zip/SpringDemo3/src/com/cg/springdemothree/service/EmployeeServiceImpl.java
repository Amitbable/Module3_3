package com.cg.springdemothree.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.springdemothree.dao.EmployeeDao;

@Component("employeeservice")
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	EmployeeDao Employeedao;
	@Override
	public void getData() {
		System.out.println("Welocme to setrvice");
		Employeedao.getData();
	}

}
