package com.cg.ctr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;
import com.cg.service.ShowService;
import com.cg.service.ShowServiceImpl;

/**
 * Servlet implementation class ShowController
 */
@WebServlet(urlPatterns={"/ShowController","/BookNow","/BookTicket"})
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl="";
		ShowService sser=new ShowServiceImpl();
		switch(url)
		{
		case "/ShowController":
			try 
			{
				ArrayList<ShowDetails> sList=sser.getShowDetails();
				HttpSession session = request.getSession();
				session.setAttribute("showList", sList);
				targetUrl="showDetails.jsp";
			}
			catch (BookingException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/BookNow":
			String showId = request.getParameter("showid") ;
			try 
			{
				
				ShowDetails show = sser.getShowDetail(showId);
				request.setAttribute("Show", show);
				targetUrl="bookNow.jsp";
			}
			catch (BookingException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/BookTicket":
			
			String showName = request.getParameter("ShowName");
			double price = Double.parseDouble(request.getParameter("Price")) ;
			String customerName = request.getParameter("CustName");
			long mob =Long.parseLong(request.getParameter("MobNo"));
			int availSeats = Integer.parseInt(request.getParameter("SeatsAvail"));
			int noOfSeats = Integer.parseInt(request.getParameter("SeatsBook"));
			
			if(noOfSeats == 0 || noOfSeats < 0)
			{
				try 
				{
					throw new BookingException("Please Enter valid no of seats");
				} 
				catch (BookingException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if(availSeats < noOfSeats)
			{
				try 
				{
					throw new BookingException("Please Enter valid no of seats");
				}
				catch (BookingException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				int updatedSeats = availSeats-noOfSeats ;
				request.setAttribute("showname", showName);
				request.setAttribute("cname", customerName);
				request.setAttribute("mobileNo", mob);
				request.setAttribute("noOfSeats", noOfSeats);
				double totalPrice = price * noOfSeats ;
				request.setAttribute("totalPrice", totalPrice);
				try 
				{
					sser.updateShowDetails(updatedSeats , showName);
					targetUrl="success.jsp";
				} 
				catch (BookingException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			break ;

	default:
		break;
	}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request,response);
	}
}
